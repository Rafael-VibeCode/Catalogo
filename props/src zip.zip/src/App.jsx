import './App.css'
import Cartao from './cartao';
import pessoas from './dados_pessoas.js';
import Topo from './Topo.jsx';
import Rodape from './Rodape.jsx';

function App() {
 return (
   <>
    <Topo />

    <div className='container'>
      {pessoas.map((pessoas)=>{
        return <Cartao
        foto={pessoas.foto}
        nome={pessoas.nome}
        idade={pessoas.idade}
        email={pessoas.email}
        telefone={pessoas.telefone}
         />;

      })}
   
     
    </div>
    <Rodape />
    </>
  );
}

export default App
