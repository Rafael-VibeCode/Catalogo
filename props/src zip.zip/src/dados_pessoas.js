import foto1 from './imagens/rambo.jpg';
import foto2 from './imagens/ellen.png';
import foto3 from './imagens/o-maskara.jpg';
import foto4 from './imagens/Nielsen.jpg';
import foto5 from './imagens/tom.jpg';
import foto6 from './imagens/sarah.jpg';

const pessoas = [
  {
    id: 1,
    foto: foto1,
    nome: "Marcos",
    idade: 25,
    email: 'marcos@gmail.com',
    telefone: '7599999999'
  },
   {
    id: 2,
    foto: foto2,
    nome: "Ana",
    idade: 35,
    email: 'Ana@gmail.com',
    telefone: '7599999999'
  },
   {
    id: 3,
    foto: foto3,
    nome: "Carlos",
    idade: 35,
    email: 'carlos@gmail.com',
    telefone: '7599999999'
  },
    {
    id: 4,
    foto: foto4,
    nome: "João",
    idade: 25,
    email: 'joao@gmail.com',
    telefone: '7599999999'
  },
   {
    id: 5,
    foto: foto5,
    nome: "Marcelo",
    idade: 30,
    email: 'celo@gmail.com',
    telefone: '7599999999'
  },
   {
    id: 6,
    foto: foto6,
    nome: "Damares",
    idade: 85,
    email: 'dama@gmail.com',
    telefone: '7599999999'
  }  
  
];

export default pessoas;